var rgb = {
    red: "#FF0000",
    green: "#00FF00",
    blue: "#0000FF"
};

var wb = {
    white: "#FFFFFF",
    black: "#000000"
};

var colors ={};
for(var i=0; i<Object.keys(rgb).length;i++){
	var aux = Object.keys(rgb)[i];
	colors[aux]=rgb[aux];
}
for(var i=0; i<Object.keys(wb).length;i++){
	var aux = Object.keys(wb)[i];
	colors[aux]=wb[aux];
}

console.log(colors);
console.log(rgb);
console.log(wb);