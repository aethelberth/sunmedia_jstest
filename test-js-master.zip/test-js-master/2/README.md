# Test 2

El fragmento de código de nuestro fichero `test.js` nos devuelve un output no 
deseado. Queremos imprimir un valor incremental a cada segundo pero lo que 
nos devuelve el código es el mismo valor en cada iteración. 

1. Sin necesidad de ejecutar el código, ¿sabrías decirnos qué valor imprimiría
 por consola el script? ¿Cuál es el motivo?

5, porque i se sobrescribe y al lanzase setTimeout, despues de un segundo, el bucle ha finalizado e i es 5. 

2. Sabiendo que el output que buscamos es el que encuentras bajo estas líneas… 
¿Cómo solucionarías el fragmento de código para que el output sea el deseado?

```
    > 0
    > 1
    > 2
    > 3
    > 4
```

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

async function loop(){
	
	for (var i = 0; i < 5; i++) {
	   await sleep(1000);
	   console.log(i); 
	}
}

loop();
-------------------------- OR -----------------
for(let i=0;i<5;i++){
	setTimeout(()=> 
	console.log(i), 
	1000*i)
}