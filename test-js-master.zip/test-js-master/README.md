# SunMedia JS Tests

Este es el repositorio para la prueba técnica de Javascript de SunMedia. 
La prueba consta de hasta cuatro test. En cada una de las carpetas que 
separan los test encontrarás un fichero README.md que explica más detalladamente
qué es lo que se pide, así como el código asociado a la prueba. 

### Las pruebas:
- [Test 1](1)
1-
	rgb = { red: "#FF0000", green: "#00FF00", blue: "#0000FF", white: "#FFFFFF", black: "#000000" }
	wb = { white: "#FFFFFF", black: "#000000" }
	colors = { red: "#FF0000", green: "#00FF00", blue: "#0000FF", white: "#FFFFFF", black: "#000000" }

2-	
	var colors = Object.assign({},rgb, wb);
3-
	IE no acepta Object.assign.

	var colors ={};
	for(var i=0; i<Object.keys(rgb).length;i++){
		var aux = Object.keys(rgb)[i];
		colors[aux]=rgb[aux];
	}
	for(var i=0; i<Object.keys(wb).length;i++){
		var aux = Object.keys(wb)[i];
		colors[aux]=wb[aux];
	}
- [Test 2](2)
1-
	5, porque i se sobrescribe y al lanzase setTimeout, despues de un segundo, el bucle ha finalizado e i es 5.
2-
	for(let i=0;i<5;i++){
		setTimeout(()=> 
		console.log(i), 
		1000*i)
	}
- [Test 3](3)
	cambiar "=>" por "function" y añadir una libreria para que se pueda utilizar promise.

HTML:
	<head>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/bluebird/3.3.5/bluebird.min.js"></script>

JS:
	let promise = new Promise(function(resolve, reject) {
 	   setTimeout(function () {
        	if (Math.round(Math.random()) === 1) {
        	    resolve("Success!");
       	 	} else {
       	     	reject("Fail!");
        	}
    	}, 1000);
	});

	promise
	.then(function(successMessage) {
        	console.log("Yes! " + successMessage);
    	})
    	.catch(function(failMessage) {
        	console.log("No! " + failMessage);
    	});

- [Test 4](4)

- [Test 5](5)


### Lo que valoramos
- Buenas prácticas de desarollo
- Testing
- Buen conocimiento de JavaScript

### Presentación de la prueba

La prueba puede subirse a algún repositorio público al que podamos tener 
acceso desde el equipo de desarrollo de SunMedia. 
