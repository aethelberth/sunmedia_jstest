const target = document.getElementById('sunmedia');
/**
 *
 * @param {string} src The video media file url
 * @return {HTMLVideoElement}
 */
function createVideoElement(src){
    var HTMLVideoElement = document.createElement("VIDEO");
    HTMLVideoElement.setAttribute("src", src);
    return HTMLVideoElement;

}
const videoElm = createVideoElement('https://vod.addevweb.com/sunmedia/demos/v/normal.mp4');
/**
 * @param {HTMLDivElement} targetElm
 * @param {HTMLVideoElement} videoElm
 */
function onInsertVideoWhenTargetIsVisible(targetElm, videoElm){
    //targetElm.appendChild(videoElm);
    videoElm.id = "targetVideo"
    targetElm.appendChild(videoElm);
    targetElm.innerHTML = targetElm.innerHTML.substr(0, targetElm.innerHTML.indexOf("></video>")) + "onended=\"videoEnded()\" autoplay controls muted ></video>"
}

onInsertVideoWhenTargetIsVisible(target, videoElm);