import EventManager from './EventManager';
import Event from './Event';

export default class EventManagerFactory{
    static create(events, types) {
        // implement your code here...
        events.forEach(element => {
            setTimeout(function(){ 
                console.log("At second " + element.second + ": {type: " + element.type + ", message: " + element.message +"}")},
            1000*element.second)
        });
        return new EventManager();
    }
};