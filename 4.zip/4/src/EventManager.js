export default class EventManager{
    run() {
        // implement your code here...
        console.log("RUNNING");
    }
};